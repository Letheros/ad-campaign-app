package simple.ad.campaign;

import org.springframework.data.repository.CrudRepository;

public interface CampaignRepository extends CrudRepository<Campaign, String>{

}
