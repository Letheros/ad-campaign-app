package simple.ad;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimpleAdApplication {

	public static void main(String[] args) {
		SpringApplication.run(SimpleAdApplication.class, args);
	}
}
