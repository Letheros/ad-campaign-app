import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ad-campaign-start',
  templateUrl: './ad-campaign-start.component.html',
  styleUrls: ['./ad-campaign-start.component.css']
})
export class AdCampaignStartComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
