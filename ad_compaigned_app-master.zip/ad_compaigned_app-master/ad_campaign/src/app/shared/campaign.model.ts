export class Campaign {
  constructor(public id: number, public duration: string, public ad_content: string) {}
}
